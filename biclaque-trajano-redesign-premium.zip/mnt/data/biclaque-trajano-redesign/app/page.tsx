import Link from 'next/link';
import { dishes, highlights, restaurant } from './data';

const img = {
  hero:'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1800&q=85',
  farm:'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1500&q=85',
  table:'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1500&q=85',
  wine:'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1500&q=85',
  plate:'https://images.unsplash.com/photo-1551218808-94e220e084d2?auto=format&fit=crop&w=1500&q=85'
};

function Nav(){return <header className="nav"><div className="shell nav-inner"><Link className="brand" href="/">Biclaque Trajano</Link><nav className="nav-links"><a href="#identidade">Identidade</a><Link href="/carta">Carta</Link><a href="#origem">Origem</a><Link href="/sustentabilidade">Sustentabilidade</Link><Link href="/reservas" className="btn dark">Reservar</Link></nav></div></header>}
function Footer(){return <footer className="footer"><div className="shell footer-grid"><div><div className="brand">Biclaque Trajano</div><p className="lead">Cozinha portuguesa contemporânea em Chaves, feita de origem, tempo e cuidado.</p></div><div><p>{restaurant.address}</p><p><a href={restaurant.phoneHref}>{restaurant.phone}</a></p><p>Todos os dias · 10:00–22:00</p></div><div><p><a href={restaurant.reservation}>Reserva online</a></p><p><a href={restaurant.instagram}>Instagram</a></p><p><a href={restaurant.facebook}>Facebook</a></p></div></div></footer>}

export default function Home(){
  return <>
    <Nav />
    <main>
      <section className="hero">
        <div className="hero-copy"><span className="eyebrow">Chaves · Trás-os-Montes</span><h1>Cozinhar é cuidar.</h1><p>Do produto. Do tempo. Da origem. De quem produz, de quem cozinha e de quem se senta à mesa.</p><div className="hero-actions"><a className="btn dark" href={restaurant.reservation}>Reservar mesa</a><Link className="btn" href="/carta">Explorar carta</Link></div></div>
        <div className="hero-media"><img src={img.hero} alt="Mesa gastronómica elegante"/><div className="plate"><b>A identidade da nossa cozinha</b><span>Produto local · Memória · Território</span></div></div>
      </section>
      <section id="identidade" className="section"><div className="shell split"><div><span className="eyebrow">Manifesto</span><h2>A experiência começa antes do prato.</h2><p className="lead">Entre serras, em Trás-os-Montes, juntámos gente única, unida em torno de uma identidade: a essência e o preceito do produto local, a par da equipa que os procura reinventar.</p><div className="thin"/><p className="lead">No Biclaque partilhamos emoções e vivências à mesa — no prato tudo tem razão de ser.</p></div><div className="photo-card"><img src={img.table} alt="Sala de restaurante acolhedora"/><span className="caption">À mesa, sem pressa</span></div></div></section>
      <section id="origem" className="section dark-section"><div className="shell split"><div className="photo-card"><img src={img.farm} alt="Horta e produção local"/><span className="caption">Pena Farm</span></div><div><span className="eyebrow">Da terra para a mesa</span><h2>A nossa horta. A nossa despensa. O nosso laboratório.</h2><p className="lead">Produção própria, sazonalidade, pickles e fermentação. Tudo com tempo, cuidado e origem.</p></div></div></section>
      <section className="section"><div className="shell"><span className="eyebrow">Carta</span><h2>Pratos com razão de ser.</h2><div className="cards">{dishes.slice(4,10).map(d=><article className="dish" key={d.name}><span className="cat">{d.cat}</span><h3>{d.name}</h3><p>{d.desc}</p><strong className="price">{d.price}</strong></article>)}</div><div style={{textAlign:'center',marginTop:36}}><Link className="btn dark" href="/carta">Ver carta completa</Link></div></div></section>
      <section className="wine"><div className="wine-copy"><span className="eyebrow">Biclaque Origens</span><h2 className="serif">Grande Reserva 2021</h2><p className="lead">650 garrafas produzidas em Vidago, sub-região de Chaves. Fruta preta madura, mirtilos, apontamentos de alcaçuz e uma boca longa, equilibrada e redonda.</p><p>Harmonização ideal para carnes fortes e pratos de maior estrutura.</p></div><img src={img.wine} alt="Vinho tinto premium"/></section>
      <section className="section dark-section"><div className="shell"><span className="eyebrow">Sustentabilidade</span><h2>Cuidar também é escolher melhor.</h2><div className="grid4">{highlights.map(([n,t])=><div className="stat" key={t}><strong>{n}</strong><span>{t}</span></div>)}</div><p className="lead" style={{marginTop:28}}>Green Key Certified Establishment · válido até ao fim de junho de 2026.</p></div></section>
      <section className="section"><div className="shell"><span className="eyebrow">Reconhecimento</span><h2>Quem vem, lembra-se.</h2><div className="quote-grid"><div className="quote"><p>“Ótimo jantar, entradas excelentes e sobremesas memoráveis.”</p><b>Maickel van Haren</b></div><div className="quote"><p>“Apresentação cuidada, equipa e ethos bem explicados, pratos deliciosos.”</p><b>Courtneys on Tour Again</b></div><div className="quote"><p>“Uma experiência incrível, ambiente e serviço excelentes. Reservar é essencial.”</p><b>André Martins</b></div></div></div></section>
      <section id="contactos" className="section"><div className="shell info"><div className="info-card"><span className="eyebrow">Reservas</span><h2>Reserve a sua mesa.</h2><p className="lead">Todos os dias das 10:00 às 22:00. Horários especiais e feriados podem variar.</p><a className="btn dark" href={restaurant.reservation}>Reserva online</a> <a className="btn" href={restaurant.phoneHref}>Ligar</a></div><iframe className="map" src={restaurant.maps} loading="lazy" title="Mapa Biclaque Trajano"/></div></section>
    </main><Footer/><a className="mobile-cta" href={restaurant.reservation}>Reservar</a>
  </>;
}
